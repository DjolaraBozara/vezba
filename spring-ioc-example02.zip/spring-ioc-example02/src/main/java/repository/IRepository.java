package repository;

public interface IRepository {
	void save(String message);
}
