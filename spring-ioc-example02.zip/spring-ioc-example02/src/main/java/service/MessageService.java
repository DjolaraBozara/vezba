package service;

public interface MessageService {
	void save (String message);
}
