package config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = {
		"repository",
		"service",
		"main"
})

public class MyBeanConfig {
	
	
}
